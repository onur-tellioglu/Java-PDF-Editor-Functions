import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;

//Add Bullet List

public class MainClass {
    public static void main(String[] args) throws IOException {
        File mainPDF = new File("D:\\Onur Tellioğlu\\Projects\\PDF Project\\PDF\\Main.pdf"); //Locate main PDF's path
        PDDocument document = PDDocument.load(mainPDF); //Load the PDF as a PDDoc object
        PDPage newPage = new PDPage(); //Create a new page object
        document.addPage(newPage); //Create new page using new page object

        File bulletFont = new File("C:\\Users\\usavm\\IdeaProjects\\PDF\\src\\main\\resources\\Fonts\\ZapfDingbats.ttf");
        PDFont bulletFont1 = PDType0Font.load(document, bulletFont);

        PDPageContentStream.AppendMode appendContent;
        PDPageContentStream contentStream = new PDPageContentStream(document, newPage);
        contentStream.beginText();
        contentStream.setLeading(25.0f);

        contentStream.newLineAtOffset(50,newPage.getTrimBox().getHeight()-50);

        String[] listItems = new String[]{
                "This is list item 1",
                "This is list item 2",
                "This is list item 3",
                "This is list item 4",
                "This is list item 5",
                "This is list item 6",
                "This is list item 7",
                "This is list item 8",
                "This is list item 9",
                "This is list item 10",
        };

        String bullet1 = "3";

        for (String listItem : listItems) {
            contentStream.setFont(bulletFont1, 18);
            contentStream.showText(bullet1);

            contentStream.setFont(PDType1Font.TIMES_ROMAN, 18);
            contentStream.showText(listItem);
            contentStream.newLine();
        }

        contentStream.endText();
        contentStream.close();

        document.save("D:\\Onur Tellioğlu\\Projects\\PDF Project\\PDF\\Result.pdf");
        System.out.println("PDF Created!");
        document.close();
    }
}
