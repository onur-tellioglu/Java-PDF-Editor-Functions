import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;

import java.io.File;
import java.io.IOException;

//Merge PDF Files In One PDF

public class MainClass {
    public static void main(String[] args) throws IOException {
        File oldFile1 = new File("C:\\Users\\usavm\\Desktop\\PDF\\Main.pdf"); //Locate first file
        File oldFile2 = new File("C:\\Users\\usavm\\Desktop\\PDF\\Copy.pdf"); //Locate second file

        File newFile = new File("C:\\Users\\usavm\\Desktop\\PDF\\Result"); //Locate the Result's folder
        newFile.mkdirs(); //Create the Result folder if it is not exist

        PDFMergerUtility pdfMergerUtility = new PDFMergerUtility(); //Create merger object
        pdfMergerUtility.setDestinationFileName(newFile + "\\Result.pdf"); //Locate Result.pdf's path

        pdfMergerUtility.addSource(oldFile1); //Input first pdf to be merged
        pdfMergerUtility.addSource(oldFile2); //Input second pdf to be merged

        pdfMergerUtility.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly()); //Merge the files

        System.out.println("PDFs are merged!");
    }
}
