import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;

import java.io.File;
import java.io.IOException;

//Change Font

public class MainClass {
    public static void main(String[] args) throws IOException {
        File mainPDF = new File("D:\\Onur Tellioğlu\\Projects\\PDF Project\\PDF\\Main.pdf"); //Locate main PDF's path
        PDDocument document = PDDocument.load(mainPDF); //Load the PDF as a PDDoc object
        PDPage newPage = new PDPage(); //Create a new page object
        document.addPage(newPage); //Create new page using new page object

        File myFont = new File("D:\\Onur Tellioğlu\\Projects\\PDF Project\\PDF\\orange juice 2.0.ttf"); //Locate font's path
        PDFont font1 = PDType0Font.load(document, myFont); //Load your font as a PDFont object

        PDPageContentStream contentStream = new PDPageContentStream(document, newPage);
        contentStream.beginText();
        contentStream.setLeading(25.0f);

        contentStream.newLineAtOffset(50,newPage.getTrimBox().getHeight()-50);
        String text = "HELLO EARTHLINGS!"; //Your text

        contentStream.setFont(font1, 20); //Font size etc.
        contentStream.showText(text);
        contentStream.newLine();

        contentStream.endText();
        contentStream.close();

        document.save("D:\\Onur Tellioğlu\\Projects\\PDF Project\\PDF\\Result.pdf");
        System.out.println("PDF Created!");
        document.close();
    }
}
