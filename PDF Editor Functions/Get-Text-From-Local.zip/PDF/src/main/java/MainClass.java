import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

//Write Text To Console

public class MainClass {
    public static void main(String[] args) throws IOException {
        int startPage = 1;
        int endPage = 9;

        File file = new File("D:\\Onur Tellioğlu\\Projects\\PDF Project\\PDF\\Main.pdf"); //Locate main PDF's path
        FileInputStream fis = new FileInputStream(file);

        PDDocument pdfDocument = PDDocument.load(fis);
        System.out.println(pdfDocument.getPages().getCount());
        PDFTextStripper pdfTextStripper = new PDFTextStripper();

        pdfTextStripper.setStartPage(startPage);
        pdfTextStripper.setEndPage(endPage);

        String docText = pdfTextStripper.getText(pdfDocument);
        System.out.println(docText);

        pdfDocument.close();
        fis.close();
    }
}
