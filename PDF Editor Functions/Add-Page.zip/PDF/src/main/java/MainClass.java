import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import java.io.File;
import java.io.IOException;

//Adding a new page to existing PDF, and exporting it as a new PDF.

public class MainClass {
    public static void main(String[] args) throws IOException {
        File oldFile = new File("C:\\Users\\usavm\\Desktop\\PDF\\try.pdf"); //Old file's path
        PDDocument document = PDDocument.load(oldFile);
        document.addPage(new PDPage());

        document.save("C:\\Users\\usavm\\Desktop\\PDF\\tryNew.pdf"); //New file's path
        System.out.println("PDF Created!");
        document.close();
    }
}
