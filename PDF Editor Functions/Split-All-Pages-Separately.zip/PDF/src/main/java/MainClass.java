import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;

import java.io.File;
import java.io.IOException;
import java.util.List;

//Split All The Pages

public class MainClass {
    public static void main(String[] args) throws IOException {
        File mainPDF = new File("C:\\Users\\usavm\\Desktop\\PDF\\Main.pdf"); //Target PDF File
        PDDocument document = PDDocument.load(mainPDF); //Loading the target PDF file as a document to operate with it.

        Splitter splitter = new Splitter(); //Creating a new Splitter object

        List<PDDocument> splitPages = splitter.split(document); //Using a list to split all the pages separately

        int num = 1; //Page Number

        for (PDDocument myDoc : splitPages) { //Loop to avoid overwriting
            myDoc.save("C:\\Users\\usavm\\Desktop\\PDF\\Splitted-Pages\\splitted_" + num + ".pdf");
            num++;
            myDoc.close(); //Closing the existing PDF file to avoid overwriting
        }

        System.out.println("Split Operation is Done.");
    }
}
