import org.apache.pdfbox.pdmodel.PDDocument;

import java.io.File;
import java.io.IOException;

//Delete Page Range From PDF File

public class MainClass {
    public static void main(String[] args) throws IOException {
        File mainFile = new File("C:\\Users\\usavm\\Desktop\\PDF\\Main.pdf"); //Creating a File object, by using the path of the main PDF file

        try (PDDocument document = PDDocument.load(mainFile)) { //Using the mainFile object to create a PDDocument object, and loading it
            int pageRangeStart = 1; //Range start as page number
            int pageRangeEnd = 10; //Range end as page number

            for (int i = pageRangeEnd; i >= pageRangeStart; i--) { //Loop for deleting the page range
                document.removePage(i-1);
            }

            document.save("C:\\Users\\usavm\\Desktop\\PDF\\Deleted.pdf"); //Saving the new version
        }

        System.out.println("PDF Created!");
    }
}
