import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;

import java.io.File;
import java.io.IOException;
import java.util.List;

//Split PDF To A Separate File

public class MainClass {
    public static void main(String[] args) throws IOException {
        String mainPath = "C:\\Users\\usavm\\Desktop\\PDF"; //Declaring the folder

        File mainFile = new File(mainPath + "\\Main.pdf"); //Declaring the PDF's name
        PDDocument document = PDDocument.load(mainFile); //Transforming the main PDF to a PDDocument object

        File newFileDestination = new File(mainPath + "\\Extracted"); //Declaring the destination folder for output
        newFileDestination.mkdirs(); //If there is no path to extract, it will create a new folder to extract

        Splitter splitterObj = new Splitter(); //Creating a Splitter object
        splitterObj.setStartPage(10); //Declaring the start page to split
        splitterObj.setEndPage(23); //Declaring the end page to split

        List<PDDocument> splitPages = splitterObj.split(document); //Creating a PDDocument list for splitting pages

        PDDocument newDoc = new PDDocument(); //Creating a new PDDocument object to save splitted PDF

        for (PDDocument myDoc : splitPages) {
            newDoc.addPage(myDoc.getPage(0));
        }

        newDoc.save(newFileDestination+"//split.pdf");
        newDoc.close();

        System.out.println("PDF Created");
    }
}
