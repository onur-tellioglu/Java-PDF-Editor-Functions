import org.apache.pdfbox.pdmodel.PDDocument;

import java.io.File;
import java.io.IOException;

//Delete A Page From PDF File

public class MainClass {
    public static void main(String[] args) throws IOException {
        File mainFile = new File("C:\\Users\\usavm\\Desktop\\PDF\\Main.pdf"); //Creating a File object, by using the path of the main PDF file

        try (PDDocument document = PDDocument.load(mainFile)) { //Using the mainFile object to create a PDDocument object, and loading it
            document.removePage(0); //Index number of the page that you want to delete
            document.save("C:\\Users\\usavm\\Desktop\\PDF\\Deleted.pdf"); //Saving the new version
        }

        System.out.println("PDF Created!");
    }
}
