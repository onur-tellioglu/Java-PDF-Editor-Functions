import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.io.File;
import java.io.IOException;

//Add Image To A PDF

public class MainClass {
    public static void main(String[] args) throws IOException {
        File mainFile = new File("C:\\Users\\usavm\\Desktop\\PDF\\Main.pdf"); //Locate main pdf
        PDDocument document = PDDocument.load(mainFile); //Load it as a PDDocument object

        PDPage newPage = new PDPage(); //Create new page to add your img
        document.addPage(newPage); //Add your page to your document

        PDImageXObject img1 = PDImageXObject.createFromFile("C:\\Users\\usavm\\Desktop\\PDF\\moon-knight.jpg", document); //Load your img
        PDPageContentStream contentStream = new PDPageContentStream(document, newPage); //Locate the page to add your img
        contentStream.drawImage(img1, 0,240); //Locate pixels
        contentStream.close(); //Close the function

        document.save("C:\\Users\\usavm\\Desktop\\PDF\\Result.pdf"); //Save document as a new PDF file
        document.close(); //Close function
        System.out.println("Image added to the PDF!"); //Inform user
    }
}
