import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import java.io.IOException;

//CREATING A NEW PDF FILE

public class MainClass {
    public static void main(String[] args) throws IOException {
        PDDocument document = new PDDocument();
        PDPage firstPage = new PDPage();
        document.addPage(firstPage);

        document.save("C:\\Users\\usavm\\Desktop\\PDF\\PDF.pdf"); //Declaring the path
        System.out.println("PDF Created!");
        document.close();
    }
}
