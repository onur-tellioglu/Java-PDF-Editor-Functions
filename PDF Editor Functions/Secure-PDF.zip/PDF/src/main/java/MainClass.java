import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy;

import java.io.File;
import java.io.IOException;

//Set a password to PDF

public class MainClass {
    public static void main(String[] args) throws IOException {
        File mainFile = new File("C:\\Users\\usavm\\Desktop\\PDF\\Main.pdf"); //Locate main pdf
        PDDocument document = PDDocument.load(mainFile); //Load it as a PDDocument object

        final int KeyLength = 128;
        AccessPermission accessPermission = new AccessPermission(); //Create an access permission object

        //SET PERMISSIONS START
        accessPermission.setCanPrint(false);
        accessPermission.setCanAssembleDocument(false);
        accessPermission.setCanExtractContent(false);
        accessPermission.setCanExtractForAccessibility(false);
        accessPermission.setCanModify(false);
        accessPermission.setCanFillInForm(false);
        accessPermission.setCanPrintDegraded(false);
        accessPermission.setCanModifyAnnotations(false);
        //SET END

        StandardProtectionPolicy sp = new StandardProtectionPolicy("owner123", "user123", accessPermission); //Set role passwords
        sp.setEncryptionKeyLength(KeyLength); //set Encryption Key Length
        sp.setPermissions(accessPermission); //Bind access permission object

        document.protect(sp); //Protect it

        document.save("C:\\Users\\usavm\\Desktop\\PDF\\Secured.pdf"); //Save the protected version of the PDF
        document.close();

        System.out.println("PDF Protected!");
    }
}